package project;
import java.util.*;
public class RunMutex {
	static Scanner input = new Scanner(System.in);
	public static void main(String[] args) {
		Admin admin =new Admin();
		
		
		Factory factory;
		
			loginOptions();
			String lOption = input.nextLine();
			while(!(lOption.equals("0"))){
				
				if(lOption.equals("1")){
					System.out.println("Enter username:");
					String un = input.nextLine();{
					System.out.println("Enter Password:");
					String pass = input.nextLine();
					
					if(un.equals("admin") && pass.equals("admin")){
						adminOption();
						String adminOption = input.nextLine();
						while(!(adminOption.equals("0"))){
							if(adminOption.equals("1")){
								String airName="";
								flightsName();
								int choice = input.nextInt();
								if(choice ==1){
									airName = "emirates";
								}
								else if(choice ==2){
									airName = "flynass";
								}
								else if(choice == 3){
									airName = "qatar";
								}
								
								
								System.out.println("Enter the date:");
								String departure = "Sialkot";
								String date = input.nextLine();
								System.out.println("Enter No. of seats:");
								int capacity = input.nextInt();
								System.out.println("Enter Flight No.");
								int flightNo = input.nextInt();
								System.out.println("Enter Arrival");
								String arrival = input.nextLine();
								System.out.println("Enter gross cost for this airline:");
								double grossCost = input.nextDouble();
								Fare fare = new Fare(grossCost);
								factory = new Factory();
								admin.addFlight(factory.getFlight(airName,departure,date,capacity,flightNo,arrival,fare));
								
							}
							if(adminOption.equals("2")){
								
								admin.printFlight();
								System.out.println("Enter the number to be removed:");
								int flightNo = input.nextInt();
								admin.removeFlight(flightNo-1);
								
								
							}
							adminOption();
							adminOption = input.nextLine();
						}
					}
				}
			}
				if(lOption.equals("2")){
					
				}
				
				
				
			}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

	public static void loginOptions(){
		System.out.println("Press 1 to login as admin");
		System.out.println("Press 2 to login as Agent");
		System.out.println("Press 0 to exit");
		
	}
	

	 public static void adminOption(){
		 System.out.println("press 1 to add Flight");
		 System.out.println("press 2 to remove flight");
		 System.out.println("press 0 to logout");
	 }
	 public static void agentOption(){
		 System.out.println("Press 1 to book Flight");
	 }
	 public static void flightsName(){
		 System.out.println("1- Emirates");
		 System.out.println("2- Flynass");
		 System.out.println("3- Qatar");
	 }
	 

}
