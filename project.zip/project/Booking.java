package project;
import java.util.*;


public class Booking {
	private Flight flight;
	private String bookingReference;
	
	
	public Booking(){
		
		
	}
	public void setBookingReference(){
		this.bookingReference = getBookingReference();
	}
	public String getBookingReference(){
		String s="ABCDEFGHIGKLMNOPQRSTUVYXYZ";
		String ns="123456789";

		String genrate="";
		Random r = new Random();
		

		for (int i=0;i<3 ;i++ ) {
			int r1 = r.nextInt(26);
			int r2 = r.nextInt(9);	

			char c=s.charAt(r1);
			char c1=ns.charAt(r2);
			genrate+=Character.toString(c);
			genrate+=Character.toString(c1);
			
		}


		return genrate;
	}
	public Flight getFlight() {
		return flight;
	}
	public void setFlight(Flight flight) {
		this.flight = flight;
	}
	
	
}
