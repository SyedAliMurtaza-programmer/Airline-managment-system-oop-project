package project;
import java.util.*;
public class Agent {
	private ArrayList<Booking> booking = new ArrayList<Booking>();
	private ArrayList<Passenger> passenger = new ArrayList<Passenger>();
	public void addBooking(Booking b){
		this.booking.add(b);
	}
	public void addPassenger(Passenger p){
		this.passenger.add(p);
	}
}
