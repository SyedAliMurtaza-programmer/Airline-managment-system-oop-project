package project;

public class Airport {
	private Airline airline;
	public Airport(){
		
	}
	
	public void setAirline(Airline a){
		airline = a;
	}
	
	
	public Airline getAirline(){
		return this.airline;
	}
}
